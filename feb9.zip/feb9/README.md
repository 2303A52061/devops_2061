# Expense Tracker (React + Express)

This workspace contains a backend Express API and a React (Vite) frontend for a simple Expense Tracker.

Folders:
- backend: Express server on port 4000
- client: Vite + React app on port 3000

See the individual READMEs for run instructions.
