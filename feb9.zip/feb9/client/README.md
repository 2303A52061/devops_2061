# Expense Tracker Client

Client built with React + Vite. Connects to backend at http://localhost:4000

Run:

1. cd client
2. npm install
3. npm run dev
