import React, { useEffect, useState } from 'react'

function ExpenseForm({ onAdd }) {
  const [title, setTitle] = useState('')
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState('')
  const [category, setCategory] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const clear = () => { setTitle(''); setAmount(''); setDate(''); setCategory('') }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    if (!title || !amount || Number(amount) <= 0 || !date) {
      setError('Please fill required fields and use positive amount')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('http://localhost:4000/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, amount: Number(amount), category, date })
      })
      if (!res.ok) throw new Error('Failed to add expense')
      const data = await res.json()
      onAdd(data)
      clear()
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="expense-form">
      <h3>Add Expense</h3>
      {error && <div className="error">{error}</div>}
      <label>
        Title*<input value={title} onChange={e => setTitle(e.target.value)} />
      </label>
      <label>
        Amount*<input value={amount} onChange={e => setAmount(e.target.value)} type="number" step="0.01" />
      </label>
      <label>
        Date*<input value={date} onChange={e => setDate(e.target.value)} type="date" />
      </label>
      <label>
        Category<input value={category} onChange={e => setCategory(e.target.value)} />
      </label>
      <button type="submit" disabled={loading}>{loading ? 'Adding...' : 'Add'}</button>
    </form>
  )
}

function ExpensesList({ items }) {
  if (!items.length) return <div>No expenses yet</div>
  return (
    <ul className="expenses-list">
      {items.map(exp => (
        <li key={exp.id} className="expense-item">
          <div className="left">
            <strong>{exp.title}</strong>
            <div className="meta">{exp.category} • {exp.date}</div>
          </div>
          <div className="amount">${Number(exp.amount).toFixed(2)}</div>
        </li>
      ))}
    </ul>
  )
}

export default function App() {
  const [expenses, setExpenses] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let mounted = true
    setLoading(true)
    fetch('http://localhost:4000/api/expenses')
      .then(r => r.json())
      .then(data => { if (mounted) setExpenses(data) })
      .catch(err => { if (mounted) setError('Failed to load expenses') })
      .finally(() => { if (mounted) setLoading(false) })
    return () => { mounted = false }
  }, [])

  const handleAdd = (newExpense) => {
    // Prepend so newest appears first
    setExpenses(prev => [newExpense, ...prev])
  }

  return (
    <div className="container">
      <h1>Expense Tracker</h1>
      <div className="main">
        <ExpenseForm onAdd={handleAdd} />
        <div className="list-wrap">
          <h3>Expenses</h3>
          {loading ? <div>Loading...</div> : error ? <div className="error">{error}</div> : <ExpensesList items={expenses} />}
        </div>
      </div>
    </div>
  )
}
