# Expense Tracker Backend

Simple Express backend with two endpoints:

- GET /api/expenses
- POST /api/expenses

Run:

1. cd backend
2. npm install
3. npm start
