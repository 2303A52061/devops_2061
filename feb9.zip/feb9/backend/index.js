const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

// In-memory "database"
const expenses = [
  { id: uuidv4(), title: 'Coffee', amount: 3.5, category: 'Food', date: '2026-02-01' },
  { id: uuidv4(), title: 'Groceries', amount: 45.2, category: 'Shopping', date: '2026-02-03' }
];

app.get('/api/expenses', (req, res) => {
  res.json(expenses);
});

app.post('/api/expenses', (req, res) => {
  const { title, amount, category, date } = req.body;
  if (!title || !amount || amount <= 0 || !date) {
    return res.status(400).json({ error: 'Invalid expense data' });
  }
  const newExpense = { id: uuidv4(), title, amount: Number(amount), category: category || 'Other', date };
  expenses.push(newExpense);
  res.status(201).json(newExpense);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend listening on http://localhost:${PORT}`));
